//
//  ContentView.swift
//  SampleBankingApp
//
//  Created by Ercument Turkmenoglu on 19/05/2026.
//

#if canImport(ContactCenterMessagingSDK)
import ContactCenterMessagingSDK
#endif
import Foundation
import Observation
import SwiftUI
import UIKit

private enum ChatConfiguration {
    static let defaultWidgetId = "0de0d803-0c29-4359-af19-f8842a1f89da"
    static let defaultOrgId = "2f7ae9e9-d5c5-f011-89f5-6045bd5bd6f4"
    static let defaultOrgUrl = "https://m-2f7ae9e9-d5c5-f011-89f5-6045bd5bd6f4.ca.omnichannelengagementhub.com"
    static let defaultEnvironment = "prod"
    static let defaultCustomerName = "John Smith"

    static let widgetIdKey = "d365.widgetId"
    static let orgIdKey = "d365.orgId"
    static let orgUrlKey = "d365.orgUrl"
    static let environmentKey = "d365.environment"
    static let customerNameKey = "d365.customerName"
}

private struct ChatSettings {
    var widgetId: String
    var orgId: String
    var orgUrl: String
    var environment: String
    var customerName: String

    var isComplete: Bool {
        !widgetId.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !orgId.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !orgUrl.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty &&
        !environment.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty
    }
}

private enum ChatSettingsStore {
    static var current: ChatSettings {
        ChatSettings(
            widgetId: value(forKey: ChatConfiguration.widgetIdKey, defaultValue: ChatConfiguration.defaultWidgetId),
            orgId: value(forKey: ChatConfiguration.orgIdKey, defaultValue: ChatConfiguration.defaultOrgId),
            orgUrl: value(forKey: ChatConfiguration.orgUrlKey, defaultValue: ChatConfiguration.defaultOrgUrl),
            environment: value(forKey: ChatConfiguration.environmentKey, defaultValue: ChatConfiguration.defaultEnvironment),
            customerName: value(forKey: ChatConfiguration.customerNameKey, defaultValue: ChatConfiguration.defaultCustomerName)
        )
    }

    private static func value(forKey key: String, defaultValue: String) -> String {
        let storedValue = UserDefaults.standard.string(forKey: key) ?? defaultValue
        let trimmedValue = storedValue.trimmingCharacters(in: .whitespacesAndNewlines)
        return trimmedValue.isEmpty ? defaultValue : trimmedValue
    }
}

struct ContentView: View {
    @State private var isShowingChat = false
    @State private var isShowingSettings = false

    private let accounts = [
        BankAccount(name: "Everyday Checking", maskedNumber: "•••• 2408", balance: "AED 8,421.13", change: "+AED 1,284 this month", tint: .blue),
        BankAccount(name: "High Yield Savings", maskedNumber: "•••• 1130", balance: "AED 24,890.75", change: "+AED 118 interest YTD", tint: .green),
        BankAccount(name: "Rewards Credit", maskedNumber: "•••• 7781", balance: "AED 1,204.22", change: "AED 5,295 available", tint: .purple)
    ]

    var body: some View {
        NavigationStack {
            ScrollView {
                VStack(alignment: .leading, spacing: 24) {
                    headerView
                    totalBalanceView
                    accountsView
                    recentActivityView
                    liveChatView
                }
                .padding(20)
            }
            .background(Color(.systemGroupedBackground))
            .toolbar {
                ToolbarItem(placement: .topBarTrailing) {
                    Button {
                        isShowingSettings = true
                    } label: {
                        Label("Settings", systemImage: "gearshape.fill")
                    }
                }
            }
            .fullScreenCover(isPresented: $isShowingChat) {
                NativeChatView(isPresented: $isShowingChat)
            }
            .sheet(isPresented: $isShowingSettings) {
                ChatSettingsView()
            }
        }
    }

    private var headerView: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Good afternoon")
                .font(.subheadline)
                .foregroundStyle(.secondary)
            Text("John")
                .font(.largeTitle.weight(.bold))
        }
        .frame(maxWidth: .infinity, alignment: .leading)
    }

    private var totalBalanceView: some View {
        VStack(alignment: .leading, spacing: 16) {
            HStack(alignment: .top) {
                VStack(alignment: .leading, spacing: 6) {
                    Text("Total Balance")
                        .font(.subheadline.weight(.medium))
                        .foregroundStyle(.secondary)
                    Text("AED 33,311.88")
                        .font(.system(size: 36, weight: .bold, design: .rounded))
                        .minimumScaleFactor(0.75)
                }

                Spacer()

                Image(systemName: "building.columns.fill")
                    .font(.title2)
                    .foregroundStyle(.white)
                    .frame(width: 46, height: 46)
                    .background(Color.accentColor, in: Circle())
            }

            HStack(spacing: 12) {
                SummaryMetric(title: "Income", value: "AED 6,420", systemImage: "arrow.down.left.circle.fill", color: .green)
                SummaryMetric(title: "Spending", value: "AED 3,118", systemImage: "arrow.up.right.circle.fill", color: .orange)
            }
        }
        .padding(20)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
    }

    private var accountsView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Account Summary")
                .font(.headline)

            ForEach(accounts) { account in
                AccountRow(account: account)
            }
        }
    }

    private var recentActivityView: some View {
        VStack(alignment: .leading, spacing: 12) {
            Text("Recent Activity")
                .font(.headline)

            TransactionRow(title: "Payroll Deposit", subtitle: "Today", amount: "+AED 3,210.00", amountColor: .green)
            TransactionRow(title: "Card Payment", subtitle: "Yesterday", amount: "-AED 840.00", amountColor: .primary)
            TransactionRow(title: "Grocery Market", subtitle: "May 17", amount: "-AED 86.34", amountColor: .primary)
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
    }

    private var liveChatView: some View {
        VStack(alignment: .leading, spacing: 14) {
            HStack(spacing: 12) {
                Image(systemName: "message.fill")
                    .font(.title3)
                    .foregroundStyle(.white)
                    .frame(width: 42, height: 42)
                    .background(Color.blue, in: Circle())

                VStack(alignment: .leading, spacing: 4) {
                    Text("Need help?")
                        .font(.headline)
                    Text("Start a secure live chat with customer support.")
                        .font(.subheadline)
                        .foregroundStyle(.secondary)
                }
            }

            Button {
                isShowingChat = true
            } label: {
                Label("Start Live Chat", systemImage: "bubble.left.and.bubble.right.fill")
                    .font(.headline)
                    .frame(maxWidth: .infinity)
                    .padding(.vertical, 14)
            }
            .buttonStyle(.borderedProminent)
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}

private struct ChatSettingsView: View {
    @Environment(\.dismiss) private var dismiss
    @AppStorage(ChatConfiguration.widgetIdKey) private var widgetId = ChatConfiguration.defaultWidgetId
    @AppStorage(ChatConfiguration.orgIdKey) private var orgId = ChatConfiguration.defaultOrgId
    @AppStorage(ChatConfiguration.orgUrlKey) private var orgUrl = ChatConfiguration.defaultOrgUrl
    @AppStorage(ChatConfiguration.environmentKey) private var environment = ChatConfiguration.defaultEnvironment
    @AppStorage(ChatConfiguration.customerNameKey) private var customerName = ChatConfiguration.defaultCustomerName

    var body: some View {
        NavigationStack {
            Form {
                Section("Customer Context") {
                    SettingsTextField(
                        title: "Name",
                        placeholder: ChatConfiguration.defaultCustomerName,
                        text: $customerName,
                        textInputAutocapitalization: .words
                    )
                }

                Section("D365 Contact Center") {
                    SettingsTextField(
                        title: "Widget ID",
                        placeholder: ChatConfiguration.defaultWidgetId,
                        text: $widgetId
                    )
                    SettingsTextField(
                        title: "Organization ID",
                        placeholder: ChatConfiguration.defaultOrgId,
                        text: $orgId
                    )
                    SettingsTextField(
                        title: "Organization URL",
                        placeholder: ChatConfiguration.defaultOrgUrl,
                        text: $orgUrl,
                        keyboardType: .URL
                    )
                    Picker("Environment", selection: $environment) {
                        Text("Production").tag("prod")
                        Text("Test").tag("test")
                    }
                }

                Section {
                    Button("Restore Demo Defaults") {
                        widgetId = ChatConfiguration.defaultWidgetId
                        orgId = ChatConfiguration.defaultOrgId
                        orgUrl = ChatConfiguration.defaultOrgUrl
                        environment = ChatConfiguration.defaultEnvironment
                        customerName = ChatConfiguration.defaultCustomerName
                    }
                }
            }
            .navigationTitle("Chat Settings")
            .navigationBarTitleDisplayMode(.inline)
            .toolbar {
                ToolbarItem(placement: .confirmationAction) {
                    Button("Done") {
                        dismiss()
                    }
                }
            }
        }
    }
}

private struct SettingsTextField: View {
    let title: String
    let placeholder: String
    @Binding var text: String
    var keyboardType: UIKeyboardType = .default
    var textInputAutocapitalization: TextInputAutocapitalization = .never

    var body: some View {
        VStack(alignment: .leading, spacing: 6) {
            Text(title)
                .font(.caption.weight(.semibold))
                .foregroundStyle(.secondary)

            TextField(placeholder, text: $text)
                .textInputAutocapitalization(textInputAutocapitalization)
                .autocorrectionDisabled()
                .keyboardType(keyboardType)
        }
        .padding(.vertical, 4)
    }
}

private struct NativeChatView: View {
    @Binding var isPresented: Bool
    @State private var viewModel = NativeChatViewModel()
    @State private var draftMessage = ""
    @State private var isShowingSettings = false
    @State private var keyboardHeight: CGFloat = 0
    @FocusState private var isComposerFocused: Bool

    var body: some View {
        NavigationStack {
            VStack(spacing: 0) {
                chatStatusBar

                ScrollViewReader { proxy in
                    ScrollView {
                        LazyVStack(spacing: 12) {
                            ForEach(viewModel.messages) { message in
                                ChatBubble(message: message)
                                    .id(message.id)
                            }

                            Color.clear
                                .frame(height: 1)
                                .id(ChatScrollTarget.bottom)
                        }
                        .padding(.horizontal, 16)
                        .padding(.vertical, 18)
                    }
                    .background(Color(.systemGroupedBackground))
                    .contentShape(Rectangle())
                    .simultaneousGesture(
                        TapGesture().onEnded {
                            dismissKeyboard()
                        }
                    )
                    .onChange(of: viewModel.lastMessageID) { _, _ in
                        scrollToBottom(using: proxy, animated: false)
                    }
                    .onChange(of: isComposerFocused) { _, isFocused in
                        guard isFocused else {
                            return
                        }

                        scrollToBottom(using: proxy, animated: true)
                    }
                    .onChange(of: keyboardHeight) { _, _ in
                        scrollToBottom(using: proxy, animated: true)
                    }
                }

                composerView
            }
            .navigationTitle("Contoso Support")
            .navigationBarTitleDisplayMode(.inline)
            .toolbarBackground(Color(.systemBackground), for: .navigationBar)
            .toolbarBackground(.visible, for: .navigationBar)
            .toolbar {
                ToolbarItem(placement: .topBarLeading) {
                    Button {
                        dismissKeyboard()
                        Task {
                            await viewModel.endChat()
                            isPresented = false
                        }
                    } label: {
                        Label("Close", systemImage: "xmark")
                    }
                }

                ToolbarItemGroup(placement: .topBarTrailing) {
                    Button {
                        isShowingSettings = true
                    } label: {
                        Label("Settings", systemImage: "gearshape")
                    }

                    Button {
                        dismissKeyboard()
                        Task {
                            await viewModel.restartChat()
                        }
                    } label: {
                        Label("Reload Chat", systemImage: "arrow.clockwise")
                    }

                    Button {
                        dismissKeyboard()
                        Task {
                            await viewModel.endChat()
                        }
                    } label: {
                        Label("End Chat", systemImage: "phone.down.fill")
                    }
                    .tint(.red)
                }
            }
            .sheet(isPresented: $isShowingSettings) {
                ChatSettingsView()
            }
            .task {
                await viewModel.startChat()
            }
            .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillShowNotification)) { notification in
                keyboardHeight = keyboardHeight(from: notification)
            }
            .onReceive(NotificationCenter.default.publisher(for: UIResponder.keyboardWillHideNotification)) { _ in
                keyboardHeight = 0
            }
        }
    }

    private var chatStatusBar: some View {
        HStack(spacing: 10) {
            Circle()
                .fill(viewModel.status.color)
                .frame(width: 9, height: 9)

            Text(viewModel.status.title)
                .font(.caption.weight(.medium))
                .foregroundStyle(.secondary)

            Spacer()

            if viewModel.isStarting {
                ProgressView()
                    .controlSize(.small)
            }
        }
        .padding(.horizontal, 16)
        .padding(.vertical, 10)
        .background(Color(.systemBackground))
    }

    private var composerView: some View {
        HStack(alignment: .bottom, spacing: 10) {
            TextField("Message support", text: $draftMessage, axis: .vertical)
                .focused($isComposerFocused)
                .lineLimit(1...4)
                .padding(.horizontal, 14)
                .padding(.vertical, 11)
                .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 8, style: .continuous))

            Button {
                sendDraftMessage()
            } label: {
                Image(systemName: "arrow.up.circle.fill")
                    .font(.system(size: 34, weight: .semibold))
            }
            .disabled(draftMessage.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty || viewModel.isSending)
        }
        .padding(12)
        .background(Color(.systemBackground))
    }

    private func sendDraftMessage() {
        let message = draftMessage.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !message.isEmpty else {
            return
        }

        draftMessage = ""
        dismissKeyboard()
        Task {
            await viewModel.sendMessage(message)
        }
    }

    private func scrollToBottom(using proxy: ScrollViewProxy, animated: Bool) {
        Task { @MainActor in
            try? await Task.sleep(nanoseconds: 120_000_000)

            if animated {
                withAnimation(.easeOut(duration: 0.2)) {
                    proxy.scrollTo(ChatScrollTarget.bottom, anchor: .bottom)
                }
            } else {
                proxy.scrollTo(ChatScrollTarget.bottom, anchor: .bottom)
            }
        }
    }

    private func keyboardHeight(from notification: Notification) -> CGFloat {
        guard let frame = notification.userInfo?[UIResponder.keyboardFrameEndUserInfoKey] as? CGRect else {
            return 0
        }

        return frame.height
    }

    private func dismissKeyboard() {
        isComposerFocused = false
        UIApplication.shared.sendAction(#selector(UIResponder.resignFirstResponder), to: nil, from: nil, for: nil)
    }
}

@Observable
@MainActor
private final class NativeChatViewModel {
    var messages: [ChatMessage] = []
    var status: ChatConnectionStatus = .disconnected
    var isStarting = false
    var isSending = false

    var lastMessageID: String? {
        messages.last?.id
    }

    private let service: D365MessagingService
    private var hasStarted = false
    private var seenMessageIDs = Set<String>()

    init() {
        self.service = D365MessagingService()
    }

    func startChat() async {
        guard !hasStarted else {
            return
        }

        hasStarted = true
        isStarting = true
        status = .connecting
        appendSystemMessage("Connecting you to Contoso Support...")

        do {
            appendSystemMessage("Preparing the D365 messaging session...")
            try await service.configure()
            appendSystemMessage("Starting secure chat...")
            try await service.startChat()
            status = .connected
            appendSystemMessage("You are connected. A support specialist will respond here.")
            listenForMessages()
        } catch {
            status = .failed
            appendSystemMessage(error.localizedDescription)
        }

        isStarting = false
    }

    func sendMessage(_ text: String) async {
        let localMessage = ChatMessage(author: "You", text: text, timestamp: Date(), direction: .customer)
        appendMessage(localMessage)
        isSending = true

        do {
            try await service.sendMessage(text)
        } catch {
            appendSystemMessage("Message failed: \(error.localizedDescription)")
        }

        isSending = false
    }

    func endChat() async {
        do {
            try await service.endChat()
            status = .disconnected
            appendSystemMessage("Chat ended.")
        } catch {
            appendSystemMessage("Could not end chat: \(error.localizedDescription)")
        }
    }

    func restartChat() async {
        _ = try? await service.endChat()
        messages.removeAll()
        seenMessageIDs.removeAll()
        hasStarted = false
        await startChat()
    }

    private func listenForMessages() {
        Task { [weak self] in
            guard let self else {
                return
            }

            do {
                for try await message in service.messages() {
                    appendMessage(message)
                }
            } catch {
                status = .failed
                appendSystemMessage(error.localizedDescription)
            }
        }
    }

    private func appendSystemMessage(_ text: String) {
        appendMessage(ChatMessage(author: "System", text: text, timestamp: Date(), direction: .system))
    }

    private func appendMessage(_ message: ChatMessage) {
        guard !seenMessageIDs.contains(message.id) else {
            return
        }

        seenMessageIDs.insert(message.id)
        messages.append(message)
    }
}

private enum ChatScrollTarget {
    static let bottom = "chat-scroll-bottom"
}

@MainActor
private struct D365MessagingService {
    func configure() async throws {
        #if canImport(ContactCenterMessagingSDK)
        let settings = ChatSettingsStore.current
        guard settings.isComplete else {
            throw ChatServiceError.missingConfiguration
        }

        print("[D365Chat] configure settings widgetId=\(settings.widgetId) orgId=\(settings.orgId) orgUrl=\(settings.orgUrl) environment=\(settings.environment) customerName=\(settings.customerName)")

        let omniChannelConfig = LCWOmniChannelConfigRequest(
            orgId: settings.orgId,
            orgUrl: settings.orgUrl,
            widgetId: settings.widgetId
        )
        LiveChatMessaging.shared.showDebugPrint(showPrint: true)
        LiveChatMessaging.shared.initialize(
            omniChannelConfig: omniChannelConfig,
            chatSDKconfig: LCWChatSDKConfigRequest(),
            initializeChatConfig: nil,
            authToken: nil,
            environment: settings.environment
        )

        guard let viewController = UIApplication.shared.activeViewController else {
            throw ChatServiceError.missingViewController
        }

        try await performSDKCall(timeoutSeconds: 20, timeoutMessage: "D365 chat SDK initialization timed out.") { completion in
            LiveChatMessaging.shared.initOmnichannelChatSDK(viewController) { success, error in
                Self.logSDKResult(operation: "initOmnichannelChatSDK", success: success, error: error)
                if let errorMessage = error?.getErrorMessage() {
                    completion(.failure(ChatServiceError.sdkError(errorMessage)))
                } else if success != nil {
                    completion(.success(()))
                } else {
                    completion(.success(()))
                }
            }
        }
        #else
        throw ChatServiceError.sdkNotLinked
        #endif
    }

    func startChat() async throws {
        #if canImport(ContactCenterMessagingSDK)
        let settings = ChatSettingsStore.current
        let customContext = ["Name": settings.customerName]
        LiveChatMessaging.shared.setCustomContext(customContext: customContext)
        print("[D365Chat] startChat customContext=\(customContext)")

        try await performSDKCall(timeoutSeconds: 30, timeoutMessage: "D365 did not start the chat session in time.") { completion in
            LiveChatMessaging.shared.startChat(nil) { success, error in
                Self.logSDKResult(operation: "startChat", success: success, error: error)
                if let errorMessage = error?.getErrorMessage() {
                    completion(.failure(ChatServiceError.sdkError(errorMessage)))
                } else {
                    completion(.success(()))
                }
            }
        }
        #else
        throw ChatServiceError.sdkNotLinked
        #endif
    }

    func sendMessage(_ text: String) async throws {
        #if canImport(ContactCenterMessagingSDK)
        let request = LCWSendMessageRequest(content: text, tags: nil, timestamp: Date(), metadata: nil)
        try await performSDKCall(timeoutSeconds: 15, timeoutMessage: "D365 did not send the message in time.") { completion in
            LiveChatMessaging.shared.sendMessage(params: request, id: UUID().uuidString) { success, error in
                Self.logSDKResult(operation: "sendMessage", success: success, error: error)
                if let errorMessage = error?.getErrorMessage() {
                    completion(.failure(ChatServiceError.sdkError(errorMessage)))
                } else {
                    completion(.success(()))
                }
            }
        }
        #else
        throw ChatServiceError.sdkNotLinked
        #endif
    }

    func messages() -> AsyncThrowingStream<ChatMessage, Error> {
        AsyncThrowingStream { continuation in
            #if canImport(ContactCenterMessagingSDK)
            func listen() {
                let request = LCWGetMessageRequest(rehydrate: false)
                LiveChatMessaging.shared.onNewMessage(request) { response, error in
                    Self.logSDKResult(operation: "onNewMessage", success: response, error: error)
                    if let errorMessage = error?.getErrorMessage() {
                        continuation.finish(throwing: ChatServiceError.sdkError(errorMessage))
                        return
                    }

                    if let response {
                        Self.logIncomingMessage(response)
                    }

                    if let response, let message = ChatMessage(response: response) {
                        continuation.yield(message)
                    }

                    listen()
                }
            }

            listen()
            #else
            continuation.finish(throwing: ChatServiceError.sdkNotLinked)
            #endif
        }
    }

    func endChat() async throws {
        #if canImport(ContactCenterMessagingSDK)
        try await performSDKCall(timeoutSeconds: 15, timeoutMessage: "D365 did not end the chat in time.") { completion in
            LiveChatMessaging.shared.endOCSDKChat { success, error in
                Self.logSDKResult(operation: "endOCSDKChat", success: success, error: error)
                if let errorMessage = error?.getErrorMessage() {
                    completion(.failure(ChatServiceError.sdkError(errorMessage)))
                } else {
                    completion(.success(()))
                }
            }
        }
        #else
        throw ChatServiceError.sdkNotLinked
        #endif
    }

    nonisolated private static func logSDKResult(operation: String, success: LCWResponse?, error: LCWResponse?) {
        print("[D365Chat] \(operation) successResponse=\(success?.getResponse() ?? [:])")
        print("[D365Chat] \(operation) successErrorMessage=\(success?.getErrorMessage() ?? "nil")")
        print("[D365Chat] \(operation) successErrorProperties=\(success?.getErrorProperties() ?? [:])")
        print("[D365Chat] \(operation) errorResponse=\(error?.getResponse() ?? [:])")
        print("[D365Chat] \(operation) errorMessage=\(error?.getErrorMessage() ?? "nil")")
        print("[D365Chat] \(operation) errorProperties=\(error?.getErrorProperties() ?? [:])")
    }

    nonisolated private static func logIncomingMessage(_ response: LCWGetMessageResponse) {
        print("[D365Chat] incomingMessage response=\(response.getResponse() ?? [:])")
        print("[D365Chat] incomingMessage messageId=\(response.messageId ?? "nil")")
        print("[D365Chat] incomingMessage messageType=\(response.messageType ?? "nil")")
        print("[D365Chat] incomingMessage displayName=\(response.displayName ?? "nil")")
        print("[D365Chat] incomingMessage content=\(response.content ?? "nil")")
        print("[D365Chat] incomingMessage properties=\(response.properties ?? [:])")
        print("[D365Chat] incomingMessage additionalProperties=\(response.additionalProperties)")
    }

    private func performSDKCall(
        timeoutSeconds: UInt64,
        timeoutMessage: String,
        operation: (@escaping (Result<Void, Error>) -> Void) -> Void
    ) async throws {
        let completion = SDKCompletion()

        try await withCheckedThrowingContinuation { (continuation: CheckedContinuation<Void, Error>) in
            completion.setContinuation(continuation)
            operation { result in
                completion.resume(with: result)
            }

            Task {
                try? await Task.sleep(nanoseconds: timeoutSeconds * 1_000_000_000)
                completion.resume(with: .failure(ChatServiceError.sdkError(timeoutMessage)))
            }
        }
    }
}

private final class SDKCompletion: @unchecked Sendable {
    private let lock = NSLock()
    private var continuation: CheckedContinuation<Void, Error>?
    private var didResume = false

    func setContinuation(_ continuation: CheckedContinuation<Void, Error>) {
        lock.lock()
        self.continuation = continuation
        lock.unlock()
    }

    func resume(with result: Result<Void, Error>) {
        lock.lock()
        guard !didResume, let continuation else {
            lock.unlock()
            return
        }

        didResume = true
        self.continuation = nil
        lock.unlock()

        switch result {
        case .success:
            continuation.resume()
        case .failure(let error):
            continuation.resume(throwing: error)
        }
    }
}

private extension UIApplication {
    var activeViewController: UIViewController? {
        connectedScenes
            .compactMap { $0 as? UIWindowScene }
            .flatMap(\.windows)
            .first { $0.isKeyWindow }?
            .rootViewController?
            .topMostViewController
    }
}

private extension UIViewController {
    var topMostViewController: UIViewController {
        if let presentedViewController {
            return presentedViewController.topMostViewController
        }

        if let navigationController = self as? UINavigationController, let visibleViewController = navigationController.visibleViewController {
            return visibleViewController.topMostViewController
        }

        if let tabBarController = self as? UITabBarController, let selectedViewController = tabBarController.selectedViewController {
            return selectedViewController.topMostViewController
        }

        return self
    }
}

private enum ChatServiceError: LocalizedError {
    case sdkNotLinked
    case missingConfiguration
    case missingViewController
    case sdkError(String)

    var errorDescription: String? {
        switch self {
        case .sdkNotLinked:
            "The D365 Contact Center Messaging SDK is not linked to this app target yet. Add the local XCFrameworks from Downloads to activate live chat."
        case .missingConfiguration:
            "Chat settings are incomplete. Check Widget ID, Organization ID, Organization URL, and Environment."
        case .missingViewController:
            "The app could not find an active view controller for D365 chat initialization."
        case .sdkError(let message):
            message
        }
    }
}

private enum ChatConnectionStatus {
    case disconnected
    case connecting
    case connected
    case failed

    var title: String {
        switch self {
        case .disconnected:
            "Disconnected"
        case .connecting:
            "Connecting"
        case .connected:
            "Connected"
        case .failed:
            "Connection issue"
        }
    }

    var color: Color {
        switch self {
        case .disconnected:
            .gray
        case .connecting:
            .orange
        case .connected:
            .green
        case .failed:
            .red
        }
    }
}

private struct ChatMessage: Identifiable, Equatable {
    let id: String
    let author: String
    let text: String
    let timestamp: Date
    let direction: ChatMessageDirection

    init(id: String = UUID().uuidString, author: String, text: String, timestamp: Date, direction: ChatMessageDirection) {
        self.id = id
        self.author = author
        self.text = text
        self.timestamp = timestamp
        self.direction = direction
    }

    #if canImport(ContactCenterMessagingSDK)
    nonisolated init?(response: LCWGetMessageResponse) {
        guard let content = response.content?.trimmingCharacters(in: .whitespacesAndNewlines), !content.isEmpty else {
            return nil
        }

        let type = response.messageType?.lowercased() ?? ""
        let displayName = response.displayName?.trimmingCharacters(in: .whitespacesAndNewlines)
        let author = displayName?.isEmpty == false ? displayName! : "Support"

        let stableFallbackID = [author, type, response.timestamp ?? "", content].joined(separator: "|")

        self.id = response.messageId ?? stableFallbackID
        self.author = author
        self.text = content
        self.timestamp = Date()
        self.direction = type.contains("customer") ? .customer : .agent
    }
    #endif
}

private enum ChatMessageDirection {
    case customer
    case agent
    case system
}

private struct MessageText: View {
    let message: ChatMessage

    var body: some View {
        if message.direction == .customer {
            Text(message.text)
                .textSelection(.enabled)
        } else if let attributedText = try? AttributedString(markdown: markdownTextWithHardLineBreaks) {
            Text(attributedText)
                .textSelection(.enabled)
        } else {
            Text(message.text)
                .textSelection(.enabled)
        }
    }

    private var markdownTextWithHardLineBreaks: String {
        normalizedMarkdownText
            .replacingOccurrences(of: "\r\n", with: "\n")
            .replacingOccurrences(of: "\n", with: "  \n")
    }

    private var normalizedMarkdownText: String {
        var text = message.text.replacingOccurrences(of: "\r\n", with: "\n")
        text = text.replacingOccurrences(of: "⸻", with: "\n\n")
        text = insertingSectionBreaks(in: text)
        text = insertingProductBullets(in: text)
        text = text.replacingOccurrences(of: "\n\n\n+", with: "\n\n", options: .regularExpression)
        return text.trimmingCharacters(in: .whitespacesAndNewlines)
    }

    private func insertingSectionBreaks(in text: String) -> String {
        var formattedText = text
        for heading in Self.sectionHeadings {
            formattedText = formattedText.replacingOccurrences(of: heading, with: "\n\n\(heading)\n")
        }
        return formattedText
    }

    private func insertingProductBullets(in text: String) -> String {
        var formattedText = text
        for heading in Self.productHeadings {
            formattedText = formattedText.replacingOccurrences(of: heading, with: "\n- \(heading)\n")
        }
        return formattedText
    }

    private static let sectionHeadings = ["Cashback Cards", "Lifestyle Cards", "Travel Cards", "Rewards Cards"]

    private static let productHeadings = [
        "FAB Cashback Credit Card",
        "Blue FAB Credit Card",
        "FAB ADNOC Rewards Credit Card",
        "FAB Z Card",
        "FAB SHARE Credit Cards",
        "FAB GEMS World Credit Card",
        "FAB Travel Card",
        "Etihad Guest Credit Cards",
        "FAB Rewards Active Credit Card",
        "FAB Elite Credit Card"
    ]
}

private struct ChatBubble: View {
    let message: ChatMessage

    var body: some View {
        HStack(alignment: .bottom) {
            if message.direction == .customer {
                Spacer(minLength: 44)
            }

            VStack(alignment: message.direction == .customer ? .trailing : .leading, spacing: 5) {
                if message.direction != .customer {
                    Text(message.author)
                        .font(.caption.weight(.medium))
                        .foregroundStyle(.secondary)
                }

                MessageText(message: message)
                    .font(.body)
                    .foregroundStyle(foregroundStyle)
                    .padding(.horizontal, 14)
                    .padding(.vertical, 10)
                    .background(backgroundStyle, in: RoundedRectangle(cornerRadius: 8, style: .continuous))

                Text(message.timestamp, style: .time)
                    .font(.caption2)
                    .foregroundStyle(.secondary)
            }

            if message.direction != .customer {
                Spacer(minLength: 44)
            }
        }
        .frame(maxWidth: .infinity)
    }

    private var foregroundStyle: Color {
        switch message.direction {
        case .customer:
            .white
        case .agent, .system:
            .primary
        }
    }

    private var backgroundStyle: Color {
        switch message.direction {
        case .customer:
            .blue
        case .agent:
            Color(.secondarySystemGroupedBackground)
        case .system:
            Color(.tertiarySystemGroupedBackground)
        }
    }
}

private struct BankAccount: Identifiable {
    let id = UUID()
    let name: String
    let maskedNumber: String
    let balance: String
    let change: String
    let tint: Color
}

private struct AccountRow: View {
    let account: BankAccount

    var body: some View {
        HStack(spacing: 14) {
            Image(systemName: "creditcard.fill")
                .font(.title3)
                .foregroundStyle(account.tint)
                .frame(width: 42, height: 42)
                .background(account.tint.opacity(0.12), in: Circle())

            VStack(alignment: .leading, spacing: 4) {
                Text(account.name)
                    .font(.subheadline.weight(.semibold))
                Text(account.maskedNumber)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer(minLength: 12)

            VStack(alignment: .trailing, spacing: 4) {
                Text(account.balance)
                    .font(.subheadline.weight(.semibold))
                Text(account.change)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }
        }
        .padding(16)
        .background(Color(.secondarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}

private struct SummaryMetric: View {
    let title: String
    let value: String
    let systemImage: String
    let color: Color

    var body: some View {
        HStack(spacing: 8) {
            Image(systemName: systemImage)
                .foregroundStyle(color)
            VStack(alignment: .leading, spacing: 2) {
                Text(title)
                    .font(.caption)
                    .foregroundStyle(.secondary)
                Text(value)
                    .font(.subheadline.weight(.semibold))
            }
        }
        .frame(maxWidth: .infinity, alignment: .leading)
        .padding(12)
        .background(Color(.tertiarySystemGroupedBackground), in: RoundedRectangle(cornerRadius: 8, style: .continuous))
    }
}

private struct TransactionRow: View {
    let title: String
    let subtitle: String
    let amount: String
    let amountColor: Color

    var body: some View {
        HStack {
            VStack(alignment: .leading, spacing: 3) {
                Text(title)
                    .font(.subheadline.weight(.medium))
                Text(subtitle)
                    .font(.caption)
                    .foregroundStyle(.secondary)
            }

            Spacer()

            Text(amount)
                .font(.subheadline.weight(.semibold))
                .foregroundStyle(amountColor)
        }
        .padding(.vertical, 6)
    }
}

#Preview {
    ContentView()
}
